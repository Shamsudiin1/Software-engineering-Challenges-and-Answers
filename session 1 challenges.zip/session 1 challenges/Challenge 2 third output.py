name=input("Enter your name:")
lname=input("Enter your last name:")
age=input("Enter your age: ")
print("Your first name is: " + (name.upper()) + " \nYour last name is: " + (lname.upper()) + " \nYour age is: " + age)
