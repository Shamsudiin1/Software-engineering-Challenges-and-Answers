message = 'Hello world'

print(len(message))
