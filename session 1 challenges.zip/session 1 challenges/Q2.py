print(type("1.5"))
print(type(2.0))
print(type(528))
print(type(False))