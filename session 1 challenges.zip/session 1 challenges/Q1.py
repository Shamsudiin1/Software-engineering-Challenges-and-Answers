print(type("Hello"))
print(type("007"))