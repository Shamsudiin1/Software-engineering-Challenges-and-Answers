a = 6 
b = 3 
a /= 2 * b  
print(a)  