message = 'I am shamsudiin'
print(message)

message = 'and I am learning to code with Python'
print(message)