Name = 'Eric'
Question = 'would you like to learn some Python today?'

Message = Name + ', ' + Question

print(input(Message))