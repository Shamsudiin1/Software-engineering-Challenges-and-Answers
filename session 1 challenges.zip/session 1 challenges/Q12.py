name=input("Enter your name:")
print(name.upper())
print(name.lower())
print(name.title())



