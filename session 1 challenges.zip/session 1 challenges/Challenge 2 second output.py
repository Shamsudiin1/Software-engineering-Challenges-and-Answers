name=input("Enter your name:")
lname=input("Enter your last name:")
age=input("Enter your age: ")
print(name + lname + " is " + age)
