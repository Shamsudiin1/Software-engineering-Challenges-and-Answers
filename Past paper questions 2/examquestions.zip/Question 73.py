class x:
    pass
class y(x):
    pass
class z(y):
    pass

X = Z()
Z = Z()
print(isintance(X, Z), isintance(Z, X))
