i = 3
while i > 0:
    i-=1
    print("*")
else:
    print("*")