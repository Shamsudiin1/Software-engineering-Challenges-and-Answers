s = '* - *'
s = 2* s + s* 2
print(s)