x = 'True' not in 'False'
print(x)

#The answer is A

