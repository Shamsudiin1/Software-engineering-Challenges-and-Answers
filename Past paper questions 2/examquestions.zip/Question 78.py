#The answer is A and B




